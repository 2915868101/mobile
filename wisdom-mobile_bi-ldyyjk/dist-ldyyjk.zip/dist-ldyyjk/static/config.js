window.WSD = {
  appName: '弋矶山医院广德分院',
  copyRight: '版权所有：广德市第一人民医院',
  appSoft: '技术支持：湖南维斯登信息科技有限公司',
  serverPath1: 'http://60.173.82.136:8082/WSDBI/',
  hospitalNo: '48518792-5' //分院
}